/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runners;

/**
 *
 * @author ahsan siddiqui
 */
class Employee
{
     private int ssn;
    private String empName;
    private int empAge;

    //Getter and Setter methods
    public int getEmpSSN(){
        return ssn;
    }

    public String getEmpName(){
        return empName;
    }

    public int getEmpAge(){
        return empAge;
    }

    public void setEmpAge(int newValue){
        empAge = newValue;
    }

    public void setEmpName(String newValue){
        empName = newValue;
    }

    public void setEmpSSN(int newValue){
        ssn = newValue;
    }
    public void Employee_(){
        System.out.println("the constructor of the class : ");
    }
}
 class Runners{
    String name;
    int age;
    
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public void setAge(int ag){
        age=ag;
      }
    public void setName(String n){
        name=n;
    }
    public Runners(){
        System.out.println("the constructor of the class : ");
    }
 
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) 
    {
         Employee emp = new Employee();
         emp.setEmpName("Mario");
         emp.setEmpAge(32);
         emp.setEmpSSN(112233);
         System.out.println("Employee Name: " + emp.getEmpName());
         System.out.println("Employee SSN: " + emp.getEmpSSN());
         System.out.println("Employee Age: " + emp.getEmpAge());
         emp.Employee_();
         
         Runners obj1=new Runners();
         obj1.setAge(21);
         obj1.setName("ahsan(fa19-bcs-113)");
         System.out.println("the student age is : "  +obj1.getAge());
         System.out.println("the student name is : "  + obj1.getName());
    }
    
}
