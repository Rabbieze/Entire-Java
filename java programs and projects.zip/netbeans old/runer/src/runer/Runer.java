/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runer;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
class Botique 
{
    Scanner s=new Scanner(System.in);
    private String code=s.next();
    private String color=s.next();
    private String size=s.next();
    private String quality=s.next();
    
    public void code(){
        System.out.println("the code is = " + code);
    }
    public void color(){
        System.out.println("the color is = " + color );
    }
    public void size(){
        System.out.println("the size is = " + size);
    }
    public void quality(){
        System.out.println(" the quality is = " + quality);
    }
    
    public Botique(String code){
        
        this.code = code;
    }
    public Botique(String code,String color ){
        this.color=color;
        
    }
    public Botique(String code,String color,String size){
        
        this.size=size;
    }
    public Botique(String code,String color,String size,String quality){
       
        this.quality=quality;
        
        this.code=code;
        this.color=color;
        this.size=size;
        this.quality=quality;
    }
    public Botique(){   
    }
}
    /**
     * @param args the command line arguments
     */
    public class Runer {
    public static void main(String[] args) {
      Botique botique=new Botique();
      botique.code();
      botique.color();
      botique.size();
      botique.quality();
      
       
        // TODO code application logic here
    }
    
}
