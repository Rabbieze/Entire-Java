/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package points;

class Point 
{
    private int x;
    private int y;
    
    public Point(){
        System.out.println("------------- ordinary constructor of the class----------------");
      //  a=0;
      //  b=0;
    }
    public Point(int a,int b)
    {
        x=a;
        y=b;
        
    }
    public void setA(int a){
        x=a;
    }
    public int getA(){
        return x;
    }
    public void setB(int b){
        y=b;
    } 
    public int getB(){
        return y;
    }
    public void Diplay_info(){
        System.out.println("x =" +x +"\n"+"y= " +y);
    }
    public void movePoint(int a,int b){
        x=x+a;
        y=y+a;
        System.out.println("x after moving = " +x +"\n"+"y after moving " +y );
    }
}
  
  public class Points{
    public static void main(String[] args) 
    {
        Point p1=new Point();
        p1.setA(3);
        p1.setB(4);
        p1.getA();
        p1.getB();
        p1.Diplay_info();
        Point p2=new Point(10,12);
        p2.movePoint(1, 5);
        p2.Diplay_info();
        // TODO code application logic here
    }
    
}
