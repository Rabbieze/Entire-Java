/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persons;

/**
 *
 * @author ahsan siddiqui
 */
 class Persons {
private String name;
public Persons()
{
name = "none";
}
public Persons(String theName)
{
name = theName;
}
public Persons(Persons theObject)
{
name = theObject.name;
}
public String getName()
{
return name;
}
public void setName(String theName)
{
name = theName;
}
public String toString()
{
return name;
}
public boolean equals(Object other)
{
return name.equals(((Persons)other).name);
}
}
 class Vehicle
{
private String mf;
private int cd;
private Persons own;
public Vehicle()
{
mf = "none";
cd = 1;
own = null;
}
public Vehicle(String themf, int numcd, Persons theown)
{
    {
mf = themf;
cd = numcd;
own = new Persons(theown);
}
public Vehicle(Vehicle other)
{
mf = other.mf;
cd = other.cd;
own = new Persons(other.own);
}
public void setmf(String newmf)
{
mf = newmf;
}
public void setcd(int newNum)
{
cd = newNum;
}
public void setown(Persons newown)
{
own = new Persons(newown);
}
public String getmf()
{
return mf;
}
public int getcd()
{
return cd;
}
public Persons getown()
{
return own;
}
public String toString()
{
return mf + ", " + cd + " cd, owned by " + own;
}
public boolean equals(Vehicle other)
{
return mf.equals(other.mf) && cd == other.cd;
}
}
 class Truck extends Vehicle
{
private double load;
public int capacity;
public Truck()
{
super();
load = 0;
capacity = 0;
}
public Truck(String m, int c,Persons p, double loads){
    
}
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
