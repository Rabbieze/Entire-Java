/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datedemo;

/**
 *
 * @author ahsan siddiqui
 */
class DateDemo2 
{
    public String month;
    public int day;
    public int year;
    
    public void DisplayDate()
    {
        System.out.println(" "+ month + " "+ day + " "+ year+ " ");
    }
}

    /**
     * @param args the command line arguments
     */
    public class DateDemo{
    public static void main(String[] args) 
    {
        DateDemo2 date,date2;
        date = new DateDemo2();
        date.month = "December";
        date.day = 31;
        date.year = 2012;
        System.out.println("date1:");
        date.DisplayDate();
        date2 = new DateDemo2();
        date2.month = "July";
        date2.day = 4;
        date2.year = 1776;
        System.out.println("date2:");
        date2.DisplayDate();
        // TODO code application logic here
    }
    
}
