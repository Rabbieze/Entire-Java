/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package display;

 /**
 *
 * @author ahsan siddiqui
 */

class Book{
private String title;
private double price;
private int noOfPages;
public void setTitle(String t)
{ 
title = t;
}
public void setPrice (double p)
{
 price = p;
}
public void setNoOfPages (int n)
{
    noOfPages = n;
}
public void display()
{
    System.out.println("BookTitle="+ title + "BookPrice=" + price + "BookPages=" +noOfPages);
}
    }
    /**
     * @param args the command line arguments
     */
    
    
    public class Display{    
    public static void main(String[] args) 
    {
        Book b1=new Book();
        b1.setTitle("OOP");
        b1.setPrice(1000);
        b1.setNoOfPages(2000);
        b1.display();
        
        Book b2= new Book();
        b2.setTitle("JAVA PROGRAMMING LANGUAGE");
        b2.setPrice(1200);
        b2.setNoOfPages(1000);
        b2.display();
        // TODO code application logic here
    }
    
}
