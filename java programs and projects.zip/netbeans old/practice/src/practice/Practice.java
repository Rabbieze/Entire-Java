/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

/**
 *
 * @author ahsan siddiqui
 */
class Student {
    int value=8;
    public void increment(Practice ObjectPas){
        value=value+1;
    }
}
    public class Practice{
    public static void main(String[] args) 
    {
        Student obj=new Student();
        System.out.println("before calling the value " +obj.value);
        Student objectpass=null;
        System.out.println("after calling the value " +obj.value);
        // TODO code application logic here
    }
    
}
