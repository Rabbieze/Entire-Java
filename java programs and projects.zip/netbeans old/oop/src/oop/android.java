/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author ahsan siddiqui
 */
public class android extends Oop {
    android(String man,String o,String m, int c)
    {
        super(man, o, m ,c);
    }
    public String getMOdel(){
        return "this is Android mobile"+ model;
        
    }
}
