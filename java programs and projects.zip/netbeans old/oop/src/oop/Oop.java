/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author ahsan siddiqui
 */
public class Oop 
{
    private String manufacture;
    private String operating_system;
    public String model;
    public int cost;
    Oop(String man,String o,String m,int c)
    {
        this.manufacture=man;
        this.operating_system=o;
        this.model=m;
        this.cost=c;
    }
        public String getModel(){
            return this.model;
        }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
{
      System.out.println();

        // TODO code application logic here
    }
}    

