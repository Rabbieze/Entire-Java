/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author ahsan siddiqui
 */
public class apple  extends Oop{
    
    apple(String man , String o, String m ,int c){
        super(man,o,m,c);
    }
    public String getModel(){
        return "this is an iphone"+model;
    }
    
}
