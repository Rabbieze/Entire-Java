/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acircle;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
public class Acircle 
{
    Scanner s=new Scanner(System.in);
    double radius=s.nextDouble();
    double diameter=s.nextDouble();
    
    public void Runner(){
        System.out.println("the radius is =" +radius);
        System.out.println("the diameter is = " +diameter);
    }
    public void Run(double r,double d){
        r=radius;
        d=diameter;
        System.out.println("the circumference of the circle is = " + radius*2*3.14);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        Acircle c1= new Acircle();
        c1.Runner();
        c1.Run(2.3, 1.4);
        // TODO code application logic here
    }
    
}
