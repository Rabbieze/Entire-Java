/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grosspay;
import java.util.Scanner;
class SalaryCalculator 
{
    private static double basehours = 40.0;
    private static double overtime = 1.5;
    private double hours, pay;

    public void setHours(double hrs){
        this.hours = hrs;
    }
    public void setHourPay(double py){
        this.pay = py;
    }
    public double calculatepay(){
        return hours > 40 ?
               (pay * basehours) + ((pay * overtime) * (hours - basehours)) :
               hours * pay;
    }
}
    public class Grosspay{
    public static void main(String[] args) 
    {
          Scanner sc = new Scanner(System.in);
        SalaryCalculator salcalculator = new SalaryCalculator();

        for(int i=1; i<4; i++){
            System.out.printf("Employee %d weekly hours: ", i);
            salcalculator.setHours(sc.nextDouble());

            System.out.printf("Employee %d hourly pay: ", i);
            salcalculator.setHourPay(sc.nextDouble());

            System.out.printf("Employee %d gross pay: %.2f \n", i, salcalculator.calculatepay());
        }
    }
}  

