/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complex;

/**
 *
 * @author ahsan siddiqui
 */
 class ComplexTest 
{
    
private double real;
private double imag;
public ComplexTest()
{
    real = 0.0; imag = 0.0; 
}
public ComplexTest (double r, double im)
{
    real = r; imag = im; 
}
public Complex Add (Complex b)
{
    Complex c_new = new Complex ();
          return c_new;
}
public void Show(){
    System.out.println(real);
}

 }
 public class Complex{
    public static void main(String[] args) 
    {
        ComplexTest C1 = new ComplexTest(11, 2.3);
        ComplexTest C2 = new ComplexTest(9, 2.3);
        C1.Show();
        C2.Show();
        
    }
   
    
}
