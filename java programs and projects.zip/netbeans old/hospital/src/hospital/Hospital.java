/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author ahsan siddiqui
 */
class Hospitals 
{
    private int rooms;
    private int beds;
    private int per_day_charges;
    private int days;
    private int patients;
    
    
    public Hospitals(){
        System.out.println(" constructor calling !! ");
    }
    
    public int getRooms(){
        return rooms;
    }
    public int getBeds(){
        return beds;
    }
    public int getcharges(){
        return per_day_charges;
    }
    public int getDays(){
        return days;
    }
    public int getPatients(){
        return patients;
    }
    public void setRooms(int newValue){
        this.rooms=newValue;
    }
    public void setBeds(int newValue){
        this.beds=newValue;
    }
    public void setcharges(int value){
        this.per_day_charges=value;
    }
    public void setDays(int day){
        this.days=day;
    }
    public void setPatients(int values){
        this.patients=values;
    }        
    public void Display(){
        System.out.println(" the number of rooms =  "  + rooms );
        System.out.println(" the number of beds =  "  +  beds  );
        System.out.println(" the charges per day =  "  + per_day_charges );
        System.out.println(" no of days a patient stayed = " + days );
        System.out.println(" no of patients : " + patients);
    }
    
    public void Bed_allotment(){
        System.out.println(" bed alloted : " +((rooms*beds)-patients));   
    }
    public void total_charges(){
        System.out.println("total charges =  "  + (per_day_charges*days));
    }
}
    public class Hospital{
    public static void main(String[] args) 
    {
        Hospitals hosp=new Hospitals();
        hosp.getBeds();
        hosp.getDays();
        hosp.getPatients();
        hosp.getcharges();
        hosp.getRooms();
        hosp.setBeds(7);
        hosp.setDays(5);
        hosp.setPatients(64);
        hosp.setRooms(10);
        hosp.setcharges(300);
        hosp.Display();
        hosp.Bed_allotment();
        hosp.total_charges();
       
    }    
}
