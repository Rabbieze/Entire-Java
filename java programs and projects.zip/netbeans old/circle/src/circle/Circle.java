/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circle;

/**
 *
 * @author ahsan siddiqui
 */
public class Circle 
{
    private double radius=1.0;
    private String color ="red";
    
    public void circle(){
        double radius =1.0;
        String color="red";
    }
    
    public void circle(double r){
        radius=r;
        color="red";
    }
    public double getRadius(){
        return radius;
    }
    public double getArea(){
        return radius*radius*Math.PI;
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Circle c1=new Circle();
        
        System.out.println("the radius of the circle"+c1.getRadius());
        
        Circle c2=new Circle();
        
        System.out.println("the area of the circle"+c2.getArea());
        
        // TODO code application logic here
    }
    
}
