/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author ahsan siddiqui
 */
public class Car {
private String color;
private int maxspeed;
public String carinfo(){
    return "the color is"+ color + "the maxspeed is"+ maxspeed;
}
Car(String carColor, int speedlimit){
    this.color=carColor;
    this.maxspeed=speedlimit;
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Car corolla = new Car("Red", 160);
Car ferrari = new Car ("Yellow", 400);
System.out.println(corolla.carinfo());
System.out.println(ferrari.carinfo());
        // TODO code application logic here
    }
    
}

//System.out.println("")