/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package courseresult;

/**
 *
 * @author ahsan siddiqui
 */
class CourseResultRun 
{
    public String studentName;
    public String courseName;
    public String grade;
    
    public void DisplayResult(){
        System.out.println("student name is: " + studentName + "\n" + "Course name is : " + courseName + "\n" +"grade of the student is : " + grade +" ");
    }
}

    /**
     * @param args the command line arguments
     */
    public class CourseResult{   
    public static void main(String[] args) 
    {
    CourseResultRun c1=new CourseResultRun ();
    c1.studentName= "Ali";
    c1.courseName= "OOP";
    c1.grade= "A";
    c1.DisplayResult();
    CourseResultRun c2=new CourseResultRun();
    c2.studentName= "Saba";
    c2.courseName= "ICP";
    c2.grade= "A+";
    c2.DisplayResult();
        // TODO code application logic here
    }
    
    }
