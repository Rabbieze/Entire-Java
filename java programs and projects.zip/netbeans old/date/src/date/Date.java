/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package date;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
public class Date {
    private int day=1;
    private int month=11;
    private int year=2001;
    
    public void Date(int day,int month,int year){
        this.day=1;
        this.month=11;
        this.year=2000;
    }
    public int getDay(){
        return day;      
    }
    public int getMonth(){
        return month;
    }
    public int getYear(){
        return year;
    }
    public Date setDay(){
        Date day=new Date();
        day.day=2;
        return day;
    }
    public Date setMonth(){
        Date month=new Date();
        month.month=12;
        return month;
    }
    public Date setYear(){
        Date year=new Date();
        year.year=2001;
        return year;
    }
    public void setDate(int day,int month,int year){
        Date date=new Date();
        date.Date(12, 2, 2001);
    }
    
     

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Date obj=new Date();
        System.out.println(obj.getDay());
        System.out.println(obj.getMonth());
        System.out.println(obj.getYear());
        
        // TODO code application logic here
    }
    
}
