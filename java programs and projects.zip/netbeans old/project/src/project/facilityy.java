/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

class facilityy extends doctor
{
    String fac_name;
   public void add_facility()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("FACILITY:-");
        fac_name = input.nextLine();
    }
    void show_facility()
    {
        System.out.println(fac_name);
    }
    void facility_detail(){
       facilityy[] f = new facilityy[20];
       for (int i = 0; i < 20; i++)
            f[i] = new facilityy();
         f[0].fac_name = "Ambulance";
        f[1].fac_name = "Admit Facility ";
        f[2].fac_name = "Canteen";
        f[3].fac_name = "Emergency";
//        Scanner input = new Scanner(System.in);
//        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
//        while (status == 1)
//        {
//            System.out.println("\n                                    MAIN MENU");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            choice = input.nextInt();
//    }
}
}

