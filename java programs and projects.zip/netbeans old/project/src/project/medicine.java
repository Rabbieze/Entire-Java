/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

class medicine extends pateint
{
    String med_name;
    String  med_company;
    String  exp_date;
    double med_cost;
    int count;
   public void new_medi()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("NAME OF THE MEDICINE:-");
        med_name = input.nextLine();
        System.out.print("COMPANY OF THE MEDICINE:-");
        med_company = input.nextLine();
        System.out.print("EXPIRY_DATE OF THE MEDICINE:-");
        exp_date = input.nextLine();
        System.out.print("COST OF THE PATIENT:-");
        med_cost = input.nextDouble();
        System.out.print("NO.OF UNITS :-");
        count = input.nextInt();
    }
    void find_medi()
    {
        System.out.println(med_name + "  \t" + med_company + "    \t" + exp_date + "     \t" + med_cost);
    }
    void medicine_detail(){
         medicine[] m = new medicine[100];
         for(int i=0;i<=100;i++)
             m[i]=new medicine();
         m[0].med_name = "REGICKS";
        m[0].med_company = " pvt";
        m[0].exp_date = "9-5-16";
        m[0].med_cost = 55.07;
        m[0].count = 8;
        m[1].med_name = "PANADOL";
        m[1].med_comp = "Ace pvt";
        m[1].exp_date = "4-4-15";
        m[1].med_cost = 500;
        m[1].count = 5;
        m[2].med_name = "BRUFHEN";
        m[2].med_comp = "Reckit";
        m[2].exp_date = "12-7-17";
        m[2].med_cost = 57.245;
        m[2].count = 56;
        m[3].med_name = "PRASTAMOL";
        m[3].med_comp = "DDF pvt";
        m[3].exp_date = "12-4-12";
        m[3].med_cost = 100.89;
        m[3].count = 100;
        Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
            System.out.println("|-----------------------------------------------------------------------------------|");
            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
            System.out.println("|-----------------------------------------------------------------------------------|");
            choice = input.nextInt();
        }

    }
}