package project;

import java.util.Scanner;

 class laboratory extends medicine {
     String facility;
    int lab_cost;
    void new_faci()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("FACILITY:-");
        facility = input.nextLine();
        System.out.print("COST :-");
        lab_cost = input.nextInt();
    }
    void facility_list()
    {
        System.out.println(facility + "\t\t" + lab_cost);
    }
    void lab_facility_detail(){
        laboratory[] l = new laboratory[20];
        for (int i = 0; i < 20; i++)
            l[i] = new laboratory();
        l[0].facility = "X-ray     ";
        l[0].lab_cost = 800;
        l[1].facility = "CT Scan   ";
        l[1].lab_cost = 1200;
        l[2].facility = "OR Scan   ";
        l[2].lab_cost = 500;
        l[3].facility = "Blood Bank";
        l[3].lab_cost = 50;
        
        Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
            System.out.println("|-----------------------------------------------------------------------------------|");
            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
            System.out.println("|-----------------------------------------------------------------------------------|");
            choice = input.nextInt();
        }
    }
    
}
