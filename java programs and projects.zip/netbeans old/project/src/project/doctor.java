/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

class doctor 
{
    String doc_id;
    String doc_name;
    String  specilist;
    String appoint;
    String doc_qualification;
    int doc_room;
   public void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID OF DOC:-");
        doc_id = input.next();
        System.out.print("NAME OF THE DOC:-");
        doc_name = input.next();
        System.out.print("SPECIALIZATION OF THE DOC:-");
        specilist = input.next();
        System.out.print("WORK TIME OF THE DOC:-");
        appoint = input.next();
        System.out.print("QUALIFICATION OF THE DOC:-");
        doc_qualification = input.next();
        System.out.print("ROOM.NO OF THE DOC:-");
        doc_room = input.nextInt();
    }
   public void doctor_info()
    {
        System.out.println(doc_id + "\n" + doc_name + "\n" + specilist + "\n" + appoint + "\n" + doc_qualification + "\n" + doc_room);
    }
   public void doctor_detail(){
         doctor[] d = new doctor[25];
         int i;
         for(i=1;i<=25;i++)
             d[1]=new doctor();
                  
        d[0].doc_id = "211453sdfbdg";
        d[0].doc_name = "Dr.Manzoor";
        d[0].specilist = "ENT";
        d[0].appoint = "5-11AM";
        d[0].doc_qualification = "MBBS,MD";
        d[0].doc_room = 17;
        d[1].doc_id = "323425";
        d[1].doc_name = "Dr.Waqas";
        d[1].specilist = "Physician";
        d[1].appoint = "10-3AM";
        d[1].doc_qualification = "MBBS,MD";
        d[1].doc_room = 45;
        d[2].doc_id = "177864";
        d[2].doc_name = "Dr.Ramsaha";
        d[2].specilist = "Surgeon";
        d[2].appoint = "8-2AM";
        d[2].doc_qualification = "BDM";
        d[2].doc_room = 8;
        d[3].doc_id = "33216";
        d[3].doc_name = "Dr.Fawad";
        d[3].specilist = "Arthopadic surgeon";
        d[3].appoint = "10-4PM";
        d[3].doc_qualification = "MBBS,MS";
        d[3].doc_room = 40;
        
        Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
            System.out.println("|-----------------------------------------------------------------------------------|");
            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
            System.out.println("|-----------------------------------------------------------------------------------|");
            choice = input.nextInt();
    }
}
}
