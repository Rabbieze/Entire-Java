/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

class pateint extends facilityy
{
    String patient_id; 
    String patient_name; 
    String disease; 
    String sex; 
    String admit_status;
    int age;
   public void new_patient()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID OF THE PATIENT :-");
        patient_id = input.nextLine();
        System.out.print("NAME OF THE PATIENT:-");
        patient_name = input.nextLine();
        System.out.print("DIEASE THAT OCCUR TO THE PATIENT:-");
        disease = input.nextLine();
        System.out.print("GENDER OF THE PATIENT:-");
        sex = input.nextLine();
        System.out.print("ADMIT_STATUS OF THE PATIENT :-");
        admit_status = input.nextLine();
        System.out.print("AGE OF THE PATIENT:-");
        age = input.nextInt();
    }
   public void patient_info()
    {
        System.out.println(patient_id + "\n" + patient_name + " \n" + disease + "\n" + sex + "\n" + admit_status + "\n" + age);
    }
    void pateint_detail(){
         pateint[] p = new pateint[100];
          for (int i = 0; i < 100; i++)
            p[i] = new pateint();
          p[0].patient_id = "123452";
        p[0].patient_name = "kiyani";
        p[0].disease = "     Cancer";
        p[0].sex = "Male";
        p[0].admit_status = "yesturday";
        p[0].age = 30;
        p[1].patient_id = "198703";
        p[1].patient_name = "Sammar";
        p[1].disease = "     Cold";
        p[1].sex = "\tMale";
        p[1].admit_status = "tommorrow";
        p[1].age = 23;
        p[2].patient_id = "141349";
        p[2].patient_name = "Ali";
        p[2].disease = "     Malariya";
        p[2].sex = "Male";
        p[2].admit_status = "next_week";
        p[2].age = 45;
        p[3].patient_id = "150978";
        p[3].patient_name = "rizwan";
        p[3].disease = "     Diabetes";
        p[3].sex = "Male";
        p[3].admit_status = "month_ago";
        p[3].age = 25;
//        
//        Scanner input = new Scanner(System.in);
//        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
//        while (status == 1)
//        {
//            System.out.println("\n                                    MAIN MENU");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            choice = input.nextInt();
//        }
    }
}