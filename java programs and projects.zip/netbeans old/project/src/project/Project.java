/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Calendar;
import java.util.Scanner;

/**
 *
 * @author ahsan siddiqui
 */
class Projects extends laboratory
{
    public void Detail_project(){
         staff[] s = new staff[100];
        int i;
        for(i=1;i<=100;i++)
            s[i] = new staff();
        doctor[] d = new doctor[25];
         for(i=1;i<=25;i++)
             d[1]=new doctor();
          facilityy[] f = new facilityy[20];
       for ( i = 0; i < 20; i++)
            f[i] = new facilityy();
       pateint[] p = new pateint[100];
        for ( i = 0; i < 100; i++)
            p[i] = new pateint();
           medicine[] m = new medicine[100];
        for(i=0;i<=100;i++)
             m[i]=new medicine();
        laboratory[] l = new laboratory[20];
        for ( i = 0; i < 20; i++)
            l[i] = new laboratory();
       
        int count1 = 4, count2 = 4, count3 = 4, count4 = 4, count5 = 4, count6 = 4;
        System.out.println("|              ---- *** WELCOME TO HOSPITAL MANAGMENT SYSTEM  *** -----                     |");       
          Scanner ss = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
         
            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
            choice = ss.nextInt();
            switch (choice)
            {
                case 1:
                    {
                        System.out.println("|                      **DOCTOR SECTION**                                        |");
                        s1 = 1;
                        while (s1 == 1)
                        {
                            System.out.println("1)ADD NEW ENTRY\n  2)EXISTING DOCTORS LIST");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        d[count1].new_doctor();count1++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("|          ID \t NAME\t SPECIALIST \t TIMING \t QUALIFICATION \t ROOM NO.        |");
                                        for (j = 0; j < count1; j++)
                                        {
                                            d[j].doctor_info();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\nRETURN TO BACK PRESS PLEASE 1 AND FOR MAIN MENU PRESS PLEASE 0");
                            s1 = ss.nextInt();
                        }
                        break;
                    }
                case 2:
                    {
                        System.out.println("|                     **PATIENT SECTION**                                        |");
                        s2 = 1;
                        while (s2 == 1)
                        {
                            System.out.println("1)ADD NEW ENTRY  \n  2)EXISTING PATIENTS LIST");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        p[count2].new_patient();count2++;
                                        break;
                                    }
                                case 2:
                                    {            
                                        System.out.println("|  ID:-    NAME:-    DISEASE:-   \tGENDER:- \t ADMIT STATUS:-   AGE:-             |");   
                                        for (j = 0; j < count2; j++) {
                                            p[j].patient_info();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                            s2 = ss.nextInt();
                        }
                        break;
                    }
                case 3:
                    {
                        s3 = 1;
                        System.out.println("|                     **MEDICINE SECTION**                                       |");
                        while (s3 == 1)
                        {
                            System.out.println("1.ADD NEW ENTRY\n2. EXISTING MEDICINES LIST");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        m[count3].new_medi();count3++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("|              NAME \t COMPANY \t EXPIRY DATE \t COST                            |");
                                        for (j = 0; j < count3; j++) {
                                            m[j].find_medi();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\n RETURN TO BACK PRESS PLEASE 0 AND FOR MAIN MENU PRESS PLEASE 1 ");
                            s3 = ss.nextInt();
                        }
                        break;
                    }
                case 4:
                    {
                        s4 = 1;
                        System.out.println("|                    **LABORATORY SECTION**                                      |");
                        while (s4 == 1)
                        {
                            System.out.println("1.Add New Entry \n2.Existing Laboratories List");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        l[count4].new_faci();count4++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("|                         FACILITIES COST                                    |");
                                        for (j = 0; j < count4; j++) {
                                            l[j].facility_list();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\n Return to Back Press 1 and for Main Menu Press 0");
                            s4 = ss.nextInt();
                        }
                        break;
                    }
                case 5:
                    {
                        s5 = 1;
                        System.out.println("|                         **HOSPITAL FACULITY SECTION**                          |");
                        while (s5 == 1)
                        {
                            System.out.println("1.ADD NEW FACILITY\n2.EXISTING FACILITIES LIST");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        f[count5].add_facility();count5++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("HOSPITAL FAC1ILITY INCLUDES:");
                                        for (j = 0; j < count5; j++) {
                                            f[j].show_facility();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\nRETURN TO BACK PRESS 1 AND FOR MAIN MENU PRESS 0");
                            s5 = ss.nextInt();
                        }
                        break;
                    }
                case 6:
                    {
                        s6 = 1;
                        System.out.println("                       **STAFF SECTION**");
                        while (s6 == 1)
                        {
                            String a = "nurse", b = "worker", c = "security";
                            System.out.println("(1).ADD THE NEW ENTERY \n(2).EXISTING NURSES LIST \n(3).EXISTING WORKERS LIST \n(4).EXISTING SECURITY LIST");
                            c1 = ss.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        s[count6].new_staff();count6++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("id \t Name \t Gender \t Salary");
                                        for (j = 0; j < count6; j++)
                                        {
                                            if (a.equals(s[j].desgn))
                                                s[j].staff_info();
                                        }
                                        break;
                                    }
                                case 3:
                                    {
                                        System.out.println("|                       id \t Name \t Gender \t Salary                            |");
                                        for (j = 0; j < count6; j++)
                                        {
                                            if (b.equals(s[j].desgn))
                                                s[j].staff_info();
                                        }
                                        break;
                                    }
                                case 4:
                                    {
                                        System.out.println("|                   ID \t NAME \t GENDER \t SALARY                               |");
                                        for (j = 0; j < count6; j++)
                                        {
                                            if (c.equals(s[j].desgn))
                                                s[j].staff_info();
                                        }
                                        break;
                                    }
                            }
                            System.out.println("\n RETURN TO BACK PLEASE PRESS '1' AND FOR MAIN MENU PLEASE PRESS '0'");
                            s6 = ss.nextInt();
                        }
                        break;
                    }
                default:
                    {
                        System.out.println(" YOU HAVE ENTERED WRONG CHOICE IT IS NOT IN THE LIST!!!");
                    }
            }
            System.out.println("\n RETURN  TO MAIN MENU Press '1'");
            status = ss.nextInt();
        }
    }

}
public class Project{
    
    public static void main(String args[])
    {
       staff stf=new staff();
       stf.new_staff();
       stf.staff_detail();
       stf.staff_info();
       doctor doc=new doctor();
       doc.doctor_detail();
       doc.doctor_info();
       doc.new_doctor();
       facilityy fac=new facilityy();
       fac.add_facility();
       fac.facility_detail();
       fac.show_facility();
       pateint patient=new pateint();
       patient.patient_info();
       patient.new_patient();
       patient.pateint_detail();
       medicine medical=new medicine();
       medical.find_medi();
       medical.new_medi();
       medical.medicine_detail();
       laboratory lab=new laboratory();
       lab.facility_list();
       lab.new_faci();
       lab.lab_facility_detail();
       Projects hospital=new Projects();
       hospital.Detail_project();
    
        System.out.println("the end of the project hospital managment !!!!!!");
}
    
}
