/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

class staff
{
   String staff_id;
   String staff_name;
   String desgn;
    String gender;
   int salary;
   public void new_staff()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID OF THE STAFF MEMBER:-");
        staff_id = input.nextLine();
        System.out.print("NAME OF THE STAFF MEMBER:-");
        staff_name = input.nextLine();
        System.out.print("DESIGNATION OF THE STAFF MEMBER :-");
        desgn = input.nextLine();
        System.out.print("GENDER OF THE STAFF MEMBER:-");
        gender = input.nextLine();
        System.out.print("SALARY OF THE STAFF MEMBER:-");
        salary = input.nextInt();
    }
    void staff_info()
    {
        System.out.println(staff_id + "\t" + staff_name + "\t" + gender + "\t" + salary);
    }
    public void staff_detail(){
        staff[] s = new staff[100];
        int i;
        for(i=1;i<=100;i++)
            s[i] = new staff();
        
         s[0].staff_id = "22";
        s[0].staff_name = "ESHA";
        s[0].desgn = "Worker";
        s[0].gender = "FEMALE";
        s[0].salary = 5000;
        s[1].staff_id = "23";
        s[1].staff_name = "SAWAIRA";
        s[1].desgn = "Nurse";
        s[1].gender = "FEMALE";
        s[1].salary = 2000;
        s[2].staff_id = "24";
        s[2].staff_name = "AMNA";
        s[2].desgn = "Worker";
        s[2].gender = "FEMALE";
        s[2].salary = 5000;
        s[3].staff_id = "25";
        s[3].staff_name = "AYESHA";
        s[3].desgn = "Nurse";
        s[3].gender = "FEMALE";
        s[3].salary = 20000;
            
//        
//        Scanner input = new Scanner(System.in);
//        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
//        while (status == 1)
//        {
//            System.out.println("\n                                    MAIN MENU");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
//            System.out.println("|-----------------------------------------------------------------------------------|");
//            choice = input.nextInt();
//        }
//    }
}
}

