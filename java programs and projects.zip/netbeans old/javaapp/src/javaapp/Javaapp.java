
package javaapp;
import java.util.Scanner;

class Javaapp {
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
