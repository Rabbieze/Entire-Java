/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package time;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
public class Time 
{
Scanner s=new Scanner(System.in);
int hour=s.nextInt();
int mint=s.nextInt();
int second=s.nextInt();

public void Time(int hour,int mint,int second){
   
}
public int getHour(){
    return hour;
}
public void setHour(){
    Time hour=new Time();
    hour.setHour();
}
public int getMinutes(){
    return mint;
}
public void setMinutes(){
    Time mint=new Time();
    mint.setMinutes();
}
public int getSecond(){
    return second;
}
public void setSecond(){
    Time second=new Time();
    second.setSecond();
}
public void toString(int hour,int mint,int second){
   
}
int count=0;
public void nextSecond(){
    count+=1;
}
public void previousTime(){
    this.Time(12, 55, 45);
    count--;
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Time time=new Time();
        System.out.println(time.getHour());
        System.out.println(time.getMinutes());
        System.out.println(time.getSecond());
        System.out.println("you have got the output!hurray");
        // TODO code application logic here
    }
    
}
