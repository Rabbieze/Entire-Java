/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangle;

/**
 *
 * @author ahsan siddiqui
 */
public class Rectangle 
{
    private float length=1.0f;
    private float width=2.0f;
    
    public void rectangle(){
        float length=1.0f;
        float width=2.0f;
    }
    public void rectangle(float length,float width){
        this.length=length;
        this.width=width;    
    }
    public float getLength(){
        return length;
    }
    public float setLength(){
        this.length=length;
        return length;
    }
    public float getWidth(){
        return width;
    }
    public float setWidth(){
        this.width=width;
        return width;
    }
    public float getArea(){
        return length*width;
    }
    public float getPerimeter(){
        return ((length+width)/2);
    }
    public void toString(float length,float width){
        System.out.println(length);
        System.out.println(width);
        System.out.println("\t");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Rectangle rect=new Rectangle();
        System.out.println("the length is:"+rect.getLength());
        System.out.println("the width is :"+rect.getWidth());
        System.out.println("the area is :"+rect.getArea());
        System.out.println("the perimeter is :"+rect.getPerimeter());
                
        // TODO code application logic here
    }
}
