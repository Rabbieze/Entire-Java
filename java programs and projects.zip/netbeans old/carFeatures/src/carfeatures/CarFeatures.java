/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carfeatures;

import carfeatures.CarFeatures2.vehicle;

/**
 *
 * @author ahsan siddiqui
 */
class CarFeatures2 
{
    public static interface vehicle{
         public Integer getNumberOfSeats();
         public Integer getNumberOfWheels();
         public String getVehicleType();
    }
    public class Car1 implements vehicle
{
  @Override
  public Integer getNumberOfSeats()
  {
    return 5;
  }
 
  @Override
  public Integer getNumberOfWheels()
  {
    return 4;
  }
 
  @Override
  public String getVehicleType()
  {
    return "Car";
  }
 
  public Integer getNumberOfDoors()
  {
    return 2;
  }
}
    public static class Bus implements vehicle
{
 
  @Override
  public Integer getNumberOfSeats()
  {
    return 35;
  }
 
  @Override
  public Integer getNumberOfWheels()
  {
    return 6;
  }
 
  @Override
  public String getVehicleType()
  {
    return "Bus";
  }
 
  public Integer getNumberOfDoors()
  {
    return 4;
  }
}
    public abstract class Vehicle
{
  public String vehicleType;
 
  public Integer getNumberOfSeats()
  {
    if (this.vehicleType.equals("Car"))
    {
      return 5;
    }
    else if (this.vehicleType.equals("Bus"))
    {
      return 20;
    }
    else if (this.vehicleType.equals("Motorcycle"))
    {
      return 1;
    }
    return null;
  }
 
  public String getVehicleType() 
  {
    return this.vehicleType;
  }
 
  public abstract Integer getNumberOfWheels();
}
    public abstract class Car implements vehicle
{

        private String vehicleType;
  public Car ()
  {
    this.vehicleType = "Car";
  }
 
        @Override
  public Integer getNumberOfWheels()
  {
    return 4;
  }
    }
}
    /**
     * @param args the command line arguments
     */
    public class CarFeatures{
    public static void main(String[] args) 
    {
         vehicle myCar = new Car1();
    System.out.println("My " + myCar.getVehicleType() + " has " + myCar.getNumberOfSeats() + " seats.");
    System.out.println("My " + myCar.getVehicleType() + " has " + myCar.getNumberOfWheels() + " wheels.");
 
    vehicle myBus = new Bus();
    System.out.println("My " + myBus.getVehicleType() + " has " + myBus.getNumberOfSeats() + " seats.");
    System.out.println("My " + myBus.getVehicleType() + " has " + myBus.getNumberOfWheels() + " wheels.");
  }

        // TODO code application logic here
    }
    

