/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package author;

/**
 *
 * @author ahsan siddiqui
 */
public class Author 
{
    private String name="Ahsan";
    private String email="ahsan.siddiqui.sm@gmail.com";
    private char gender='M';
    
    public void author(String name,String email,char gender){
       
        this.name=name;
        this.email=email;
        this.gender=gender;
    }        
        public String getName(){
            return name;
         }
        public String setname(){
            this.name="ahsan";
            return name;
        }
        public String getEmail(){
            return email;
            }
        public String setName(){
            this.email="ahsan.siddiqui.sm@gmail.com";
            return name;
        }
        public char getGender(){
            return gender;   
        }
        public char setGender(){
            this.gender='M';
            return gender;
        }
        public void toString(String name,String email,char gender)
        {
            System.out.println(name);
            System.out.println(email);
            System.out.println(gender);
            
        }

 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Author auth=new Author();
        System.out.println("the name is :"+auth.getName());
        System.out.println("the email is :"+auth.getEmail());
        System.out.println("the gender is :"+auth.getGender());
        // TODO code application logic here
    }
    
}
