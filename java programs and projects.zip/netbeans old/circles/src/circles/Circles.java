/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circles;

/**
 *
 * @author ahsan siddiqui
 */
public class Circles 
{
    int radius;
    public void setRadius(int r){
        radius=r;
    }
    public void showCircumference(){
        double c=2*3.14*radius;
        System.out.println("circumference is "+ c);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Circles c=new Circles();
        c.setRadius(5);
        c.showCircumference();
       
        // TODO code application logic here
    }
    
}
