/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentdata;

import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
public class claculator 
{
    Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int b=s.nextInt();
    public void subtract(){
        System.out.println("the subtraction is : " + " \n"+ (a-b));
    }
    public void addition(){
        System.out.println("the sum is : " + "\n"+(a+b));
    }
    public void divide(){
        System.out.println("the division is : " + "\n" +(a/b));
    }
    }
 
    

