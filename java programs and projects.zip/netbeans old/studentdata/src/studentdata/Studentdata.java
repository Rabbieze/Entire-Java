/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentdata;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
 public class Studentdata 
{
    Scanner s=new Scanner(System.in);
    public void BioData(){
        System.out.println("ENTER THE NAME:");
        String name=s.next();
        System.out.println("ENTER THE ROLLNO:");
        int rollno=s.nextInt();
        
    }
    public void Cgpa(){
        System.out.println("ENTER THE GPA");
        double gpa=s.nextInt();
    }
    public void university(){
        System.out.println("ENTER THE UNIVERSITY NAME");
        String uniname=s.next();
    }
    public void fees(){
        System.out.println("ENTER THE FEES IN NUMBERS:");
        int fee=s.nextInt();
        
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Studentdata obj=new Studentdata();
        obj.BioData();
        obj.Cgpa();
        obj.fees();
        obj.university();
      
        claculator obj2=new claculator();
        obj2.addition();
        obj2.divide();
        obj2.subtract();
        
        
        // TODO code application logic here
    }
 }

