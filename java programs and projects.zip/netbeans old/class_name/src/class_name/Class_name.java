/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_name;

/**
 *
 * @author ahsan siddiqui
 */
class Rectangles 
{
   public int length,width;
   
   public int CalculateArea(){
       return(length*width);
   }
}

    /**
     * @param args the command line arguments
     */
public class Class_name{
    public static void main(String[] args) 
    {
        Rectangles rect=new Rectangles();
        rect.length= 10;
        rect.width = 5;
        System.out.println(rect.CalculateArea( ));
        // TODO code application logic here
    }
    
}
