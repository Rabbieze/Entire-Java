/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

/**
 *
 * @author ahsan siddiqui
 */
class Lab41 
{
   private String name;
   private int values;
   private String university;
   
   public void Data(String n,int val,String uni){
       this.name=n;
       this.values=val;
       this.university=uni;
   }
   public Lab41(String name,int val){
      this.name=name;
      this.values=val;
       final String university="comsats";
   }
   public void Display(){
       System.out.println(" the name is = " + name + " the values are =  " + values + " the name of the university is =  " + university);
   }
}
public class Lab4{
    public static void main(String[] args) 
    {
        Lab4 obj=new Lab4();
        
        // TODO code application logic here
    }
}
 