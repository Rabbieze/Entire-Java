/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounttest;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
class Account 
{
    Scanner s=new Scanner(System.in);
    private String Accountname; 
    private double balance; 
    private int withdraw=s.nextInt();
    private double remainingamount=withdraw-balance;
  
      public Account(String accname, double balance)
      {
         this.Accountname = accname; 

         
         if (balance > 0)  
            this.balance = balance;
      }  
      public void deposit(double depositAmount)                        
      {                                                                
         if (depositAmount > 0)    
            balance = balance + depositAmount; 
      }                                                                

      public double getBalance()           
      {                                    
         return balance;                   
      }                                    

      
     public void setAccountName(String accname)
      {
         this.Accountname = accname;
      }

     
      public String getAccountName()
      {         
          return Accountname;
      }
        public int ithdraw()
        {
            return withdraw;
         
    }
         public double remainamount()
         {
             return remainingamount;
         
    } 
}
public class Accounttest
  {
       public static void main(String[] args)
       {
          Account account1 = new Account("MY FIRST ACCOUNT BALANCE =", 5000.00); 
         Account account2 = new Account(" MY SECOND ACCOUNT BALANCE =", 7000.53);  

         System.out.printf("%s balance: %.2f\n",account1.getAccountName(),account1.getBalance());
         System.out.printf("%s balance: %.2f\n\n",account2.getAccountName(), account2.getBalance());

        Scanner input = new Scanner(System.in);

        System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT IN ACCOUNT NO 1 ="); 
        double depositAmount = input.nextDouble(); 
        System.out.printf("%nadding TO ACCOUNT NO:1 BALANCE =  \n\n " , depositAmount);
         account1.deposit(depositAmount); 

      
        System.out.printf("%s BALANCE : %.2f\n",account1.getAccountName(), account1.getBalance());
         System.out.printf("%s BALANCE: %.2f\n\n",account2.getAccountName(), account2.getBalance());

         System.out.print("ENTER THE MONEY YOU WANT TO DIPOSIT IN ACCOUNT NO:2 =  "); 
         depositAmount = input.nextDouble(); 
         System.out.printf("%nadding %.2f TO ACCOUNT NO:2 BALANCE  \n\n",depositAmount);
         account2.deposit(depositAmount); 

         
         System.out.printf("%s BALANCE: %.2f\n",account1.getAccountName(), account1.getBalance());
         System.out.printf("%s BALANCE: %.2f\n\n",account2.getAccountName(), account2.getBalance());
           System.out.printf("",account1.getAccountName(),account1.getBalance());
          
      } 
 } 