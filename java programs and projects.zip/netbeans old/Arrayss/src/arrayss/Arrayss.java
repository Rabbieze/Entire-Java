/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayss;

/**
 *
 * @author ahsan siddiqui
 */
    class Student{
    private String Name;
    private int[] Result_array;

    public Student(String Name, int[] Result_array) {
        Result_array = new int[5];
        this.Name = Name;
        this.Result_array = Result_array;
    }
        public void Average(Student obj1, Student obj2){
        int[] arr1 = obj1.Result_array;
        int[] arr2 = obj2.Result_array;
        int avg1 = 0,avg2 = 0;
        for(int i=0; i<5; i++){
            avg1 += arr1[i];
            avg2 += arr2[i];
        }
        
        if((avg1/5)>(avg2/5)){
            System.out.println("Higher average of student is: "+obj1.Name);
            
        }
        else if((avg1/5)<(avg2/5)){
            System.out.println("Higher average of student is: "+obj2.Name);
            
        }
        
    } 
}
  public class Arrayss{
    public static void main(String[] args) 
    
    {
        Student obj = null;
        
    }
    
}
