/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author ahsan siddiqui
 */
class Movie 
{
    private String title;
    private String studio;
    private String rating;
    Movie[] Array_class=new Movie[100];
    public Movie(String title,String studio){
        this.title=title;
        this.studio=studio;
        this.rating="PG";
    }
    public Movie(String title,String studio,String rating){
        this.title=title;
        this.studio=studio;
        this.rating=rating;
    }
    
    Movie()
    {   
    }
    public Movie[]getPG(Movie[]Array){
        for(int i=0;i<Array.length;i++){
            if(Array[i].rating=="PG"){
                Array_class[i]=Array[i];
            }
        }
        return Array_class;
    } 
    
}
    public class Project1
    {
    public static void main(String[] args) 
    {
        Movie[]Array=new Movie[100];
        Movie Main=new Movie();
        Movie obj1=new Movie("XYZ ROYALE","ABC","PUG123");
        Movie obj2=new Movie("123 ROYALE","three hundred","PUBG23");
        Movie obj3=new Movie("786 ROYALE","DEF","fast and furious8");
        Array[0]=obj1;
        Array[1]=obj2;
        Array[3]=obj3;
        
        Movie[]a=Main.getPG(Array);
        System.out.println("these are the movies whose ratings are PG :  ");
            for(int i=0;i<a.length;i++){
                System.out.println(a[i]+" " );
            }
        
        // TODO code application logic here
    }
    
}
