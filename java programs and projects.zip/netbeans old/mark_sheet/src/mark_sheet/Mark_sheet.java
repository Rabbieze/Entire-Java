/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mark_sheet;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
class Marks 
{
    Scanner s=new Scanner(System.in);
    private int Oop_marks;
    private int DLD_marks;
    private int ICT_marks;
   
    public int getOop(){
        return Oop_marks;
    }
    public int getDLD(){
        return DLD_marks;
    }
    public int getICT(){
        return ICT_marks;
    }
    public void setOop(int newValue){
        this.Oop_marks=newValue;
    }
    public void setDLD(int newValue){
        this.DLD_marks=newValue;
    }
    public void setICT(int newValue){
        this.ICT_marks=newValue;
    }    
}
    public class Mark_sheet{
    public static void main(String[] args) 
    {
        Marks marks_info=new Marks();
            marks_info.setOop(92);
            marks_info.setDLD(87);
            marks_info.setICT(78);
            
            System.out.println("THE MARKS OBTAINED IN OOP = " + marks_info.getOop() );
            System.out.println("THE MARKS OBTAINED IN DLD = " + marks_info.getDLD() );
            System.out.println("THE MARKS OBTAINED IN ICT = " + marks_info.getICT() );
        }
    }
