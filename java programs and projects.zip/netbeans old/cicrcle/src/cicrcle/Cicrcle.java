/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cicrcle;

/**
 *
 * @author ahsan siddiqui
 */
public class Cicrcle 
{
    private double radius=2.0;
    private String color="red";

    public void circle(){
        double radius =2.0;
        String color="red";
    }
    public void circle(double radius,String color){
        this.radius=radius;
        this.color=color;
    }
    public double getRadius(){
        return radius;
    }
    public double getArea(){
        return radius*radius*Math.PI;
    }
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Cicrcle circle =new Cicrcle();
        System.out.println("the radius is :"+circle.getRadius());
        System.out.println("the area is :"+circle.getArea());
        // TODO code application logic here
    }
    
}
