/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ashh;

/**
 *
 * @author ahsan siddiqui
 */


 public class Ashh{ 
 public static void complement(String number1) 
{  
    char[] number=number1.toCharArray(); 
    for (int i=0 ; i < number.length ; i++ ) 
        if (number[i] != '.') 
            number[i] = (char)((int)('9') - (int)(number[i]) + (int)('0')); 
    System.out.println( "9's complement is : "+String.valueOf(number)); 
} 
   

public static void main(String[] args) 
{ 
    String number = "345.45"; 
    complement(number); 
} 
 }