/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java;

/**
 *
 * @author ahsan siddiqui
 */   
class Java1 
{
    String name;
    public void Any()
    {
        System.out.println(" abjwgfuiw ");
    }
    public void Anny()
    {
        System.out.println("rhuiehjkeb ");
    }
    public void Java1()
    {
        System.out.println(" the class constructor  ");
    }
}
public class Java{
    public static void main(String[] args) 
    {
        Java1 jaav =new Java1();
        jaav.Anny();
        jaav.Any();
        jaav.Java1();
    }

class Java2
{
    String age;
    public void Ask()
    {
        System.out.println(" ouwiorhjkbf ");
    }
    public void Aski()
    {
        System.out.println(" qweuyfvjh ");
    }
    public void Java2()
    {
        System.out.println(" the class constructor  ");    
    }

}
}



    



