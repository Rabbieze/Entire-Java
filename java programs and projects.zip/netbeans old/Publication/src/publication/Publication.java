package publication;
public class Publication {
    private String title;
    private float price;
    public void getData(){
        String t;
        float p;
        p=0;
        System.out.println("Enter the publication of title:");
        System.out.println("Enter the price of publication of book:");
        title="t";
        price=p;
    }
    public void putData(){
        System.out.println("title of book to be published:");
        System.out.println("price of the book that is to published:");
    }
    public static void main(String[] args){
      
       
    }
}
 class Book extends Publication{
    private int pagecount;
    @Override
    public void getData(){    
    }
    public void Publication(){
        System.out.println("Enter the book pagecount:");
        Book pagecount=new Book();
        pagecount.pagecount=this.pagecount;
    }
    public void putData(){
        System.out.println("Book pagecount:");
    }
 }