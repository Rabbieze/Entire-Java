/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;
 
import java.util.Scanner;

class Students {

    private String name;
    private String rollno;
    private int age;
    public Students(){
        System.out.println("-------------ordinary constructor------------");
}
    public Students (String name, String rollno,int age)
    {
        this.name=name;
        this.rollno=rollno;
        this.age=age;
    }
    public Students ObjectPas(Students std){
        this.name=std.name;
        this.rollno=std.rollno;
        this.age=std.age;
        return std;
    }
    public void display_info(){
        System.out.println("the name is "+ this.name);
        System.out.println("the rollno is " +this.rollno);
        System.out.println("the age is " +this.age);
    }
}
    public class Student{ 
    public static void main(String[] args) {
        Scanner s =new Scanner(System.in);
        System.out.println(" enter the name :");
        String name=s.next();
        
        System.out.println("enter the rollno :");
        String rollno=s.next();
        
        System.out.println("enter the agr :");
        int age=s.nextInt();
        
        Students std=new Students(name,rollno,age);
        System.out.println("the content of the original object ");
        std.display_info();
        
        System.out.println("content of copied object ");
        Students copyStd=new Students().ObjectPas(std);
        copyStd.display_info();
            
        }
        // TODO code application logic here
    }
    

