/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;

/**
 *
 * @author ahsan siddiqui
 */
class Array 
{
    private String Student1;
    private String Student2;
    Arrays[] Array_class=new Arrays[5];
    
    public Array(String student1,String student2){
        this.Student1=student1;
        this.Student2=student2;
    }
    Array(){
        
    }
    public Arrays[]getMArks(Arrays[]Array)
    {
        for(int i=0;i<Array.length;i++)
            {
                Array_class[i]=Array[i];
            }
        return Array_class;
    } 
}
    public class Arrays{ 
   public static void main(String[] args) 
   {
       Array[]Array=new Array[5];
        Array arr=new Array();
        
       
        // TODO code application logic here
   }
    
}
