/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managmentstudent;
import javax.swing.JOptionPane;
/**
 *
 * @author ahsan siddiqui
 */
class Student 
{
    public String Name;
    public String rollno;
    public String section;
    public String behaviour;
    
    public void setparameter(String a, String b,String c,String d){
        Name=a;
        rollno=b;
        section=c;
        behaviour=d;
    }
    public void DisplayStudentData(){
        System.out.println("name: "  +  Name  + "\n" + "  rollno: "  +  rollno  + "\n" + "  section is: "  +  section  + "\n" + "  behaviour in class: "  +  behaviour);
    }
}
    /**
     * @param args the command line arguments
     */
    public class ManagmentStudent{
    public static void main(String[] args) 
    {
        Student obj=new Student();
        String a=JOptionPane.showInputDialog("WHAT IS THE NAME OF STUDENT:");
        String b=JOptionPane.showInputDialog("WHAT IS THE ROLLNUMBER:");
        String c=JOptionPane.showInputDialog("WHAT IS THE SECTION OF THE STUDENT:");
        String d=JOptionPane.showInputDialog("HOW'S THE BEHAVIOUR OF STUDENT IN CLASS:");
        obj.setparameter(a, b, c, d);
        obj.DisplayStudentData();
        // TODO code application logic here
    }
    
}
