
package contact_systm;
import java.util.Scanner;
public class groups extends contact
{
    String group_name;
    int members;
    
    public groups(){
        System.out.println("---------------the groups of the contacts-----------------------");
    }
    public void new_group(){
        Scanner input=new Scanner(System.in);
        System.out.print("NAME OF THE MEMBER IS :-");
        members = input.nextInt();
        if(members==12){
            System.out.println("the limit of the group!!");
        }
        else{
            System.out.println("the group has exceeds the limit!!!");
        }
        System.out.print("GROUP NAME IS :-");
        group_name = input.next();
    }
    public void familyGroup(){
        
         Scanner input = new Scanner(System.in);
         int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1;
        int count1=0;
       switch(members)
       {
           case 1:
           {
                      System.out.println("------------------family group-------------------");
                       s1 = 1;
                        while (s1 == 1)
                        {
                            System.out.println("1)ADD NEW ENTRY  \n  2)EXISTING CONTACT LIST");
                            c1 = input.nextInt();
                            
                        }
           }
           
       }
    
}
}
