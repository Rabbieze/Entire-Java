
package contact_systm;

import java.util.Scanner;

public class contact 
{
    String address;
    String email;
    int phone_number;
    String name;
    String reminders;
    String gender;
    
    public contact(){
        System.out.println("---------------------the contact System--------------------------");
    }
    public void new_contact(){
         Scanner input = new Scanner(System.in);
        System.out.print("NAME OF THE PERSON YOU WANT TO ADD IN THE CONTACT ");
        name= input.nextLine();
        System.out.println(" THE EMAIL ADDRESS OF THE THE PERSON ");
        email = input.nextLine();
        System.out.print("THE PERMANENT ADDRESS OF THE PERSON");
        address = input.nextLine();
        System.out.print("THE PHONE NUMBER OF THE PERSON");
        phone_number = input.nextInt();
        System.out.print(" IF ANY REMAINDER OR SOME SPECIAL EVENT  ");
        reminders = input.nextLine();
        System.out.print(" GENDER OF THE PERSON ");
        gender = input.nextLine();
    }
    public void contact_info(){
        System.out.println("the name is " + name +"\n" + "the address is " + address +"\n" +"the phone number is " +phone_number +"\n" + "the email address is  " +email 
         +"\n" +"the reminder for the person if any meeting " +reminders + "\n" +" the gender of that person "+ gender );
    }
    public void contactperson_detail(){
        contact[] c=new contact[100];
         for (int i = 0; i < 100; i++)
             c[i]=new contact();
//          c[0].name = "zulkifal";
//          c[0].address="gudwal";
//          c[0].email="fa19-bcs-49@cuiatk.edu.pk";
//          c[0].gender="prefer not to say";
//          c[0].phone_number=03000000000;
//          c[0].reminders="treat is pending on him";
//          
//          c[1].name="awais";
//          c[1].address="mirza attock";
//          c[1].email="fa19-bcs-065@cuiatk.edu.pk";
//          c[1].gender="shakht launda";
//          c[1].phone_number=030000001;
//          c[1].reminders="baon rami banda";
//          
//          c[2].name="charsi";
//          c[2].address="kutton wala chowk";
//          c[2].email="charsi@cuiatk.edu.pk";
//          c[2].gender="gay";
//          c[2].phone_number=03000005;
//          c[2].reminders="meri chars mending hy ";

         Scanner s=new Scanner(System.in);
         for(int i=0;i<c.length;i++)
         {
             
             c[i].name=s.nextLine();
             c[i].address=s.nextLine();
             c[i].email=s.nextLine();
             c[i].phone_number=s.nextInt();
             c[i].gender=s.nextLine();
             c[i].reminders=s.nextLine();
             
         }
    }
    
    
}
