/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car_detail;
import javax.swing.JOptionPane;
class car{
    private String car_number;
    private String casses_num;
    private String model;
    
    public car(){}
    public void setDisplay(String cn,String cm,String m){
         car_number=cn;
         casses_num=cm;
         model=m;
    }
    
    public void Display(){
        System.out.println("the car number is " + car_number +"\n" + "the cassses number is " + casses_num + "\n" + "the model num is  " + model );
    } 
}
public class Car_detail {

    public static void main(String[] args) 
    {
        car cr=new car();
        String x=JOptionPane.showInputDialog("What is car number?" );
        String y=JOptionPane.showInputDialog("What is casses Number?" );
        String z=JOptionPane.showInputDialog("What is model number" );
        String a=JOptionPane.showInputDialog("what is the name of the car ");
        cr.setDisplay(x, y, z  );
        cr.Display();
        System.out.println(" the name of the car "+a);
    }
    
}
