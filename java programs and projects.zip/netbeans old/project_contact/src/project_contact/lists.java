package project_contact;
import java.util.Scanner;
import java.util.ArrayList;

public class lists extends business_numbers
{
    ArrayList<contact> personalList_contacts = new ArrayList<contact>();
     Scanner s=new Scanner(System.in);
    public void lists_detail(){
        System.out.println("the contactID is :-");
        String contactID=s.next();
        System.out.println("the email address is :-");
        String email=s.next();
        System.out.println("the address of the mine is :- ");
        String address=s.next();
        System.out.println("the mobile number of the mine is :-");
        int mobile_number=s.nextInt();
        System.out.println("the name is :-");
        String name=s.next();
        System.out.println("the date of birth of mine is :-");
        String dob=s.next();
        
        ArrayList<contact> cont1 = new ArrayList<contact>();
        
        System.out.println("enter the contact you want to switch ");
        int type_contact=s.nextInt();
        if(type_contact==0)
        {
            System.out.println("it is the peresonal contact of mine:-");
    }
        else if(type_contact==1){
            System.out.println("it is the business contact of mine :-");
        }
        
        contact cont;
        if(type_contact == 1)
       {
       cont = new contact();
       } 
    }
   
}
