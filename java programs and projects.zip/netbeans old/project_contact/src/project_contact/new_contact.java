/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_contact;
import java.util.Scanner;
public class new_contact 
{
    private String name;
    private int number;
    
    public new_contact(){
        System.out.println("----------------create a new contact in your phone---------------------------");
    }
    public new_contact(String name,int number){
        this.name=name;
        this.number=number;
    }
    public String getname(){
        return name;
}
    public int getNumber(){
        return number;
    }
     public static contact createContact(String name,int number){
        return new contact(name,number);
    }
}
