package project_contact;
public class business_numbers 
{
    //private String Business_number;
    private String organization;
    private String company_name;
    
    
    public business_numbers(){
        System.out.println("-----------------------business details-------------------------------------");
    }
    public business_numbers(String contactId, String firstName, String lastName, String address, String phoneNumber, String emailAddress, String jobTitle, String organization){

    //    super(contactId, firstName, lastName, address, phoneNumber, emailAddress);

        this.company_name = jobTitle;
        this.organization = organization;
    }
    public void setorganization(String org){
        this.organization=organization;
    }
    public String getOrganization(){
        return organization;
    }
    public void setCompanyName(String cmName){
        this.company_name=cmName;
    }
    public String getCompanyName(){
        return company_name;
    }
    
    public void Display(){
        System.out.println("the company name is :- " +company_name +"\n" + "the organization in which the person is working :-" +organization );
    }
    
    
}
