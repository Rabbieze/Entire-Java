package project_contact;

public class Project_contact {

    public static void main(String[] args) 
    {
        contact cont=new contact();
        
        cont.setAddress("ahmed nagar");
        cont.getAddress();
        cont.setEmail("ahsan.siddiqui@gmail.com");
        cont.getemail();
        cont.setMobile("03345440774");
        cont.getMobile();
        cont.setcontactID("A1234fr");
        cont.getcontactid();
        cont.setName("ahsan");
        cont.getName();
        cont.Display_info_contact();
        
        myown_contact own=new myown_contact();
        own.getDoB();
        own.getPersonal_number();
        own.getMyemail();
        own.myOwn_detailed_contact();
        own.Display_info_contact();
        own.setDoB("29-oct-2001");
        own.setMyemail("fa19-bcs-113@cuiatk.edu.pk");
        
        business_numbers business=new business_numbers();
        business.setCompanyName("cyber");
        business.getCompanyName();
        business.setorganization("coding");
        business.getOrganization();
        business.Display();
        
        lists numlist=new lists();
        numlist.lists_detail();
        
        
        new_contact newcont=new new_contact();
        newcont.getname();
        newcont.getNumber();
        
        phone phnum =new phone();
        phnum.addcontact(cont);
        phnum.getContacts();
        phnum.searchContact(cont);
        phnum.updateContact(cont, cont);
        
        
        System.out.println("--------------------------the end of the project----------------------------------");
    
    }
    
}
