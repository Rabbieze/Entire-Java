/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_contact;

/**
 *
 * @author ahsan siddiqui
 */
public class contact 

{
    private String contactID;
    private String name;
    private String address;
    private String email;
    private String mobile_number;
    
    public contact(String contactid,String name,String address,String email,String mob){
        this.contactID=contactid;
        this.address=address;
        this.name=name;
        this.email=email;
        this.mobile_number=mob;
    }
    
    
    public contact(){
        System.out.println("-----------the ordinary contact system-----------------------------");
    }

   public contact(String name, int number) {}
   
    public void setcontactID(String cont ){
        this.contactID=cont;
    }
    public void setName(String n){
        this.name=n;
    }
    public void setAddress(String addr){
        this.address=addr;
    }
    public void setEmail(String eml){
        this.email=eml;
    }
    public void setMobile(String mob){
        this.mobile_number=mob;
    }
    public String getcontactid(){
        return contactID;
    }
    public String getName(){
        return name;
    }
    public String getAddress(){
        return address;
    }
    public String getemail(){
        return email;
    }
    public String getMobile(){
        return mobile_number;
    }
    
    
    public void Display_info_contact(){
        System.out.println("the contact person id is :- " + contactID +"\n "+" the name of the person is :-  " +name + "\n"+ "the address of the person  :-"
                + address +"\n"+ "the phone number of the person is :-" + mobile_number +"\n"+" the email address is :- " +email );
        System.out.println("----------------------------------------------------------------------------------------------------------------------");
    }

    void add(contact contact) {
    }

    void remove(int findPosition) {
    }

    boolean contains(contact contact) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
