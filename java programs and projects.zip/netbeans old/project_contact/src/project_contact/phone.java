/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_contact;
import java.util.ArrayList;
/**
 *
 * @author ahsan siddiqui
 */
public class phone 
{
    private int My_number;
    public ArrayList<contact>contact;
    
    public phone(){
        System.out.println("---------------------the phone contact if present or not-----------------------------------");
    }
    
    public phone(int num){
        this.My_number=num;
        this.contact=new ArrayList<contact>();
    }
    public void addcontact(contact contact){
//        if(contact>=0)
//        {
//            System.out.println("this number is present in your phone are u sure u want to replace it");
//            return contact;
//        }
//        else{
//            contact.add(contact);
//            return true;
//        }
        System.out.println(" this number is already presnet in your phone re u sure u want to replace it ");
        
    }
    public ArrayList < contact > getContacts() {
  return contact;
 }

 public void updateContact(contact oldContact, contact newContact) {
  if (findPosition(oldContact) >= 0) {
   contact.set(findPosition(oldContact), newContact);
  } else {
   System.out.println("Contact does not exist");
  }
 }
 public void removeContact(contact contact) {
  if (findPosition(contact) >= 0) {
   contact.remove(findPosition(contact));
  } else {
   System.out.println("No contact");
  }
 }

 public int searchContact(contact contact) {
  int position = findPosition(contact);
  if (contact.contains(contact)) {
   System.out.println("Item found at position");
   return position;
  }
  System.out.println("Not found");
  return -1;
 }



 private int findPosition(contact contact)
 {
  return this.contact.indexOf(contact);

 }
 private int findPosition(String name) {
  for (int i = 0; i < contact.size(); i++) {
   contact contact = this.contact.get(i);
   if (contact.getName().equals(name)) {
    return i;
   }
  }
  return -1;
 }


}

