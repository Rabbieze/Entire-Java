/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_contact;

/**
 *
 * @author ahsan siddiqui
 */
public class myown_contact extends contact 
{
   private String myemail;
   private int personal_number;
   private String dob;
   
   public myown_contact(){
       System.out.println("-----------------my contact detail------------------------");
   }
   public myown_contact(String myemail,int personal_number,String bday){
       this.myemail=myemail;
       this.dob=bday;
       this.personal_number=personal_number;
       
   }
   public void setMyemail(String email){
       this.myemail=email;
   }
   public String getMyemail(){
       return myemail;
   }
   public void setPersonal_number(int number){
       this.personal_number=number;
   }
   public int getPersonal_number(){
       return personal_number;
   }
   public void setDoB(String bday){
       this.dob=bday;
   }
   public String getDoB(){
       return dob;
   }
   
   public void myOwn_detailed_contact(){
       System.out.println("my email is  :-" +myemail +"\n"+"my personal phone number is :- " +personal_number +"\n"+"mine date of birth is :- " +dob);
   }
    
}
