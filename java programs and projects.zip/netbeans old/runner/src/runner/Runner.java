/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
class Car 
{
    int carModel;
    String carName;
    int carPrice;
    String carOwner;
    public void Cardata()
    {
        Scanner s=new Scanner(System.in);
        System.out.println("enter the car model=");
        carModel=s.nextInt();
        System.out.println("enter the car name=");
        carName=s.next();
        System.out.println("enter the car price");
        carPrice=s.nextInt();
        System.out.println("enter the name of the owner");
        carOwner=s.next();
        
    }
    public void Display(){
        System.out.println("carModel= "+carModel +"carName="+carName + " carPrice" +carPrice + "carOwner= "+ carOwner );
    }
}
    /**
     * @param args the command line arguments
     */
    public class Runner{
    public static void main(String[] args) 
    {
        Car c1=new Car();
        c1.Cardata();
        c1.Display();
        
        Car c2=new Car();
        c2.Cardata();
        c2.Display();
        
        Car c3=new Car();
        c3.Cardata();
        c3.Display();
        // TODO code application logic here
    }
    
}
