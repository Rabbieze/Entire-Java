
package hospitalproject;
import java.util.*;
import java.util.Calendar;
class staff
{
    String staff_id, staff_name, desgn, sex;
    int salary;
    void new_staff()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID:-");
        staff_id = input.nextLine();
        System.out.print("NAME:-");
        staff_name = input.nextLine();
        System.out.print("DESIGNATION:-");
        desgn = input.nextLine();
        System.out.print("SEX:-");
        sex = input.nextLine();
        System.out.print("SALARY:-");
        salary = input.nextInt();
    }
    void staff_info()
    {
        System.out.println(staff_id + "\t" + staff_name + "\t" + sex + "\t" + salary);
    }
}
class doctor
{
    String doc_id, doc_name, specilist, appoint, doc_qualification;
    int doc_room;
    void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID OF DOC:-");
        doc_id = input.nextLine();
        System.out.print("NAME OF THE DOC:-");
        doc_name = input.nextLine();
        System.out.print("SPECIALIZATION OF THE DOC:-");
        specilist = input.nextLine();
        System.out.print("WORK TIME OF THE DOC:-");
        appoint = input.nextLine();
        System.out.print("QUALIFICATION OF THE DOC:-");
        doc_qualification = input.nextLine();
        System.out.print("ROOM.NO OF THE DOC:-");
        doc_room = input.nextInt();
    }
    void doctor_info()
    {
        System.out.println(doc_id + "\t" + doc_name + "  \t" + specilist + "     \t" + appoint + "    \t" + doc_qualification + "       \t" + doc_room);
    }
}
class patient
{
    String patient_id, patient_name, disease, sex, admit_status;
    int age;
    void new_patient()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID OF THE PATIENT :-");
        patient_id = input.nextLine();
        System.out.print("NAME OF THE PATIENT:-");
        patient_name = input.nextLine();
        System.out.print("DIEASE THAT OCCUR TO THE PATIENT:-");
        disease = input.nextLine();
        System.out.print("GENDER OF THE PATIENT:-");
        sex = input.nextLine();
        System.out.print("ADMIT_STATUS OF THE PATIENT :-");
        admit_status = input.nextLine();
        System.out.print("AGE OF THE PATIENT:-");
        age = input.nextInt();
    }
    void patient_info()
    {
        System.out.println(patient_id + "\t" + patient_name + " \t" + disease + "     \t" + sex + "      \t" + admit_status + "\t" + age);
    }
}
class medical
{
    String med_name, med_comp, exp_date;
    double med_cost;
      int count;
    void new_medi()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("NAME OF THE MEDICINE:-");
        med_name = input.nextLine();
        System.out.print("COMPANY OF THE MEDICINE:-");
        med_comp = input.nextLine();
        System.out.print("EXPIRY_DATE OF THE MEDICINE:-");
        exp_date = input.nextLine();
        System.out.print("COST OF THE PATIENT:-");
        med_cost = input.nextDouble();
        System.out.print("NO.OF UNITS :-");
        count = input.nextInt();
    }
    void find_medi()
    {
        System.out.println(med_name + "  \t" + med_comp + "    \t" + exp_date + "     \t" + med_cost);
    }
}
class lab
{
    String facility;
    int lab_cost;
    void new_faci()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("FACILITY:-");
        facility = input.nextLine();
        System.out.print("COST :-");
        lab_cost = input.nextInt();
    }
    void facility_list()
    {
        System.out.println(facility + "\t\t" + lab_cost);
    }
}
class facility
{
    String fac_name;
    void add_faci()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("FACILITY:-");
        fac_name = input.nextLine();
    }
    void show_faci()
    {
        System.out.println(fac_name);
    }
}

public class HospitalProject {

  
    public static void main(String[] args) {
         String months[] = {"January","Feburary","March","April","May","June","July","August","September","Octuber","November","December" };
        Calendar calendar = Calendar.getInstance();
        int count1 = 4, count2 = 4, count3 = 4, count4 = 4, count5 = 4, count6 = 4;
        System.out.println("|----------------------------------------------------------------------------------|");
        System.out.println("|               *** WELCOME TO HOSPITAL MANAGMENT SYSTEM  ***                      |");
        System.out.println("|----------------------------------------------------------------------------------|");
        System.out.print("Date: " + months[calendar.get(Calendar.MONTH)] + " " + calendar.get(Calendar.DATE) + " " + calendar.get(Calendar.YEAR));
        System.out.println("\t\t\t\t\t\tTime: " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND));
        doctor[] d = new doctor[25];
        patient[] p = new patient[100];
        lab[] l = new lab[20];
        facility[] f = new facility[20];
        medical[] m = new medical[100];
        staff[] s = new staff[100];
        int i;
        for (i = 0; i < 25; i++)
            d[i] = new doctor();
        for (i = 0; i < 100; i++)
            p[i] = new patient();
        for (i = 0; i < 20; i++)
            l[i] = new lab();
        for (i = 0; i < 20; i++)
            f[i] = new facility();
        for (i = 0; i < 100; i++)
            m[i] = new medical();
        for (i = 0; i < 100; i++)
            s[i] = new staff();
      Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
            System.out.println("|-----------------------------------------------------------------------------------|");
            System.out.println("|1.DOCTORS  2. PATIENTS  3.MEDICINES  4.LABORATORIES  5. FACILITIES  6. STAFF       |");
            System.out.println("|-----------------------------------------------------------------------------------|");
            choice = input.nextInt();
            switch (choice)
            {
                case 1:
                    {
                        System.out.println("|--------------------------------------------------------------------------------|");
                        System.out.println("|                      **DOCTOR SECTION**                                        |");
                        System.out.println("|--------------------------------------------------------------------------------|");
                        s1 = 1;
                    }
                    break;
                  case 2:     
                    {
                        System.out.println("|--------------------------------------------------------------------------------|");
                        System.out.println("|                     **PATIENT SECTION**                                        |");
                        System.out.println("|--------------------------------------------------------------------------------|");
                        s2 = 1;
//                      
                            }
                            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                            s2 = input.nextInt();
                        }
                      
        
        //        case 3:
                    {
                        s3 = 1;
                        System.out.println("|--------------------------------------------------------------------------------|");
                        System.out.println("|                     **MEDICINE SECTION**                                       |");
                        System.out.println("|--------------------------------------------------------------------------------|");
                      }
                    
               // case 4:
                    {
                    
                        s4 = 1;
                        System.out.println("|--------------------------------------------------------------------------------|");
                        System.out.println("|                    **LABORATORY SECTION**                                      |");
                        System.out.println("|--------------------------------------------------------------------------------|");
                    }
                    
               // case 5:
                    {
                        s5 = 1;
                        System.out.println("|--------------------------------------------------------------------------------|");
                        System.out.println("|                         **HOSPITAL FACULITY SECTION**                          |");
                        System.out.println("|--------------------------------------------------------------------------------|");
                   }   
                //case 6:
                    {
                        s6 = 1;
                        System.out.println("--------------------------------------------------------------------------------");
                        System.out.println("                       **STAFF SECTION**");
                        System.out.println("--------------------------------------------------------------------------------");
                       
            }
            System.out.println("\n RETURN  TO MAIN MENU Press '1'");
            status = input.nextInt();
        }
        }
        }

    
    

