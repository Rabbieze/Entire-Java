/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeedata;
 import java.util.Scanner;
import java.util.Calendar;
/**
 *
 * @author ahsan siddiqui
 */

   
public class EmployeeData {

    String EmployeeName, EmployeeCode, DateOfJoining;
    Scanner input=new Scanner(System.in);
    Calendar c1=Calendar.getInstance();
    public void Employee_Data()
    {
    System.out.println("Enter the employee name:");
    EmployeeName=input.nextLine();

    System.out.println("Enter Employee code:");
    EmployeeCode=input.nextLine();

    System.out.println("Current date:"+(c1.get(Calendar.MONTH)+1)+"-" 
    +c1.get(Calendar.DATE)+ "-" +c1.get(Calendar.YEAR));
    }
    public void checkdate()
    {
    System.out.print("Enter his date of joining --> - should be used and all entries must be integer:");
    DateOfJoining=input.nextLine();

    }

    public static void main(String[] args)
    {
        EmployeeData E1=new EmployeeData();
        E1.Employee_Data();
        E1.checkdate();
        
        EmployeeData E2= new EmployeeData();
        E2.Employee_Data();
        E1.checkdate();
        // TODO code application logic here
    }
    
}
