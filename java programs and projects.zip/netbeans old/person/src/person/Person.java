/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;
import java.util.Scanner;

    class Computer_class{
        String memorysize;
        String wordsize;
        String storagesize;
        String speed;
        
       public Computer_class(){
            System.out.println("-------------------------Computer class ordinary constructor-----------------------------");
        }
        public Computer_class(String memorysize,String wordsize,String Stroagesize,String speed){
            this.memorysize=memorysize;
            this.wordsize=wordsize;
            this.storagesize=Stroagesize;
            this.speed=speed;
            
        }
        
        void Display(){
            System.out.println("the memory size is = "+ memorysize +"\n"+ "the wordsizze is = "+ wordsize +"\n"+"the storagesize is = "+storagesize +"\n"+"the speed is = " + speed );
            
        }
       
        }
   
   public class Person{
    public static void main(String[] args) 
    {
     Computer_class com=new Computer_class();
    Computer_class com1=new Computer_class("5Megabytes","10 Bites","10MegaBytes","15 Hertz");
    com1.Display();
    
    Laptop lpt=new Laptop();
    Laptop lpt1=new Laptop("30 cm","10 cm","25 cm","4.5 kg");
    lpt1.Display();
    
    
    }
    
}
