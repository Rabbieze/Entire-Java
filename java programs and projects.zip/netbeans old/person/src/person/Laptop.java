/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 */
package person;

public class Laptop extends Person 
{
    String length,width,height,weight;
    
    public Laptop(){
        System.out.println("-----------------------Laptop Default Constructor---------------------------------------");
        
    }
    public Laptop(String l,String w ,String h,String g){
        length=l;
        width=w;
        height=h;
        weight=g;
    }
    void Display(){
        System.out.println("the laptop length is = "+ length +"\n" +"the wigth is = " +width +"\n"+ "the height is = "+height+"\n"+"the weight is = "+ weight);
    }
    
}
