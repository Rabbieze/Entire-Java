/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package distancetest;

/**
 *
 * @author ahsan siddiqui
 */
class Distance
{
    float feet=45.53f;
    float inches=23.54f;
    
    public Distance()
    {
        System.out.println("the distnce is : " + (feet +inches));
    }
    public Distance(float ft,float inch){
        feet=ft;
        inches=inch;
    }
    public double getFeet(){
        return feet;
    }
    public double getInches(){
        return inches;
    }
    public void setFeet(float ft){
        this.feet=ft;
    }
    public void setInches(float inch){
        this.inches=inch;
    }
    
    public double Add(){
        return inches+feet;
    }
    public void Display()
    {   
        System.out.println(" the feets are : " +feet + " \n "+ " the inches are : " + inches);
    }
}
public class DistanceTest{
    public static void main(String[] args) 
    {
        Distance dist=new Distance();
        System.out.println(" the feets are : " + dist.getFeet());
        System.out.println(" the inches are :  " + dist.getInches());
       dist.Add();
       dist.Display();
       
        
        
    }
    
}
