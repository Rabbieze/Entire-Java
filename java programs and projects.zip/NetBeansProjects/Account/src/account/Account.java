/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package account;
import java.util.Scanner;
/**
 *
 * @author ahsan siddiqui
 */
public class Account 
{
    Scanner s=new Scanner(System.in);
   private int balance=s.nextInt();
   private int pincode=s.nextInt();
   private int withdraw=s.nextInt();
   private int remainingamount=balance-withdraw;
   private int deposit=s.nextInt();
    
    public void pin(){
        
        System.out.println("ENTER THE PIN CODE = " + pincode);
    }
    public void withdraw(){
        
        System.out.println("ENTER THE MONEY YOU WANT TO WITHDRAW = " +withdraw);
    }
    
    public void deposit(){
        
        System.out.println("ENTER THE MONEY YOU WANT TO DEPOSIT = " + deposit);
    }
    public void remainamount(){
        
        System.out.println("THE REMAINING BALNCE IS = " + remainingamount);
    }
    
    public void atm(){
        System.out.println(" THE BALANCE IS " + balance);
    }
    
    public void atm2(int b, int w){
        b=balance;
        w=withdraw;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Account atm= new Account();
        atm.pin();
        atm.withdraw();
        atm.deposit();
        atm.remainamount();
        atm.atm();
        atm.atm2(20000,3000);
        
        // TODO code application logic here
    }
    
}
